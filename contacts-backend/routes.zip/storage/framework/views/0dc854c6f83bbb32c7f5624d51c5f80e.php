

<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1>Add new contact</h1>
        <form action="/contacts" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="first_name">First name</label>
                <input type="text" class="form-control" name="first_name" id="first_name" placeholder="First Name">
                <small></small>
            </div>
            <div class="form-group">
                <label for="last_name">Last name</label>
                <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Last Name">
                <small></small>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                <small></small>
            </div>

            <div class="form-group">
                <label for="email">Contact Group</label>
                <select name="contact_group_id" class="form-select" aria-label="Default select example">
                    <option selected>Select Contact Group</option>
                    <?php $__currentLoopData = $contact_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cg->id); ?>"><?php echo e($cg->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            
            <button type="submit" class="btn btn-success mt-3">Submit</button>
            <a href="/contacts" class="btn btn-danger mt-3">Cancel</a>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\contacts-backend\resources\views/contacts/create.blade.php ENDPATH**/ ?>