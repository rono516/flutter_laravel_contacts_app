

<?php $__env->startSection('content'); ?>
    <div class="container">

        <h1 class="text-center">Contacts of <?php echo e(Auth::user()->name); ?></h1>
        <a href="/contacts/create" class="btn btn-primary">New contact</a>

        <?php if($contacts == null): ?>
            <p class="display-4">No contacts</p>
        <?php else: ?>
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>First name</th>
                        <th>Last name</th>
                        <th>Email</th>
                        <th>Contact Group</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($contact->first_name); ?></td>
                            <td><?php echo e($contact->last_name); ?></td>
                            <td><?php echo e($contact->email); ?></td>
                            <td><?php echo e($contact->group->name); ?></td>
                            <td>
                                <div class="btn-toolbar">
                                    <a class="btn btn-primary btn-group mr-2"
                                        href="/contacts/<?php echo e($contact->id); ?>/edit">Edit</a>
                                    <form action="/contacts/<?php echo e($contact->id); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-group">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\contacts-backend\resources\views/contacts/index.blade.php ENDPATH**/ ?>