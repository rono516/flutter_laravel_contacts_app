<?php

namespace App\Http\Controllers;

class TestController extends Controller
{
    //
}
